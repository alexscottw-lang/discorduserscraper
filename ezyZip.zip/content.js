// Discord User Exporter Pro - Content Script
let isExporting = false;
let exportedUsers = [];
let totalUsers = 0;
let currentBatch = 0;
let batchSize = 1000; // Larger batch size for speed
let scrollDelay = 50; // Faster scrolling delays
let lastScrollPosition = 0;
let scrollAttempts = 0;
let maxScrollAttempts = 3; // Fewer attempts for speed

// Discord selectors (updated for current Discord UI)
const SELECTORS = {
    memberList: '[data-list-id="members"]',
    memberItem: '[data-list-item-id^="members-"]',
    scrollContainer: '[data-list-id="members"]',
    username: '[class*="username"]',
    actualUsername: '[class*="username"] [class*="name"]',
    displayName: '[class*="username"]',
    avatar: '[class*="avatar"] img',
    role: '[class*="role"]'
};

// Alternative selectors for different Discord versions
const ALTERNATIVE_SELECTORS = {
    memberItem: '[class*="member"], [class*="user"], [data-list-item-id]',
    scrollContainer: '[class*="memberList"], [class*="members"], aside[class*="members"]'
};

function init() {
    console.log('Discord User Exporter Pro loaded');
    
    // Check if we're on a Discord page
    if (!window.location.hostname.includes('discord.com')) {
        console.log('Not on Discord, extension will not work');
        return;
    }
    
    // Listen for messages from popup with proper error handling
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        try {
            console.log('Received message:', request.action);
            
        if (request.action === 'startExport') {
            startExport(request.options);
                sendResponse({ success: true, message: 'Export started' });
        } else if (request.action === 'stopExport') {
            stopExport();
                sendResponse({ success: true, message: 'Export stopped' });
        } else if (request.action === 'getStats') {
            sendResponse({
                totalUsers: totalUsers || exportedUsers.length,
                exportedUsers: exportedUsers.length,
                isExporting: isExporting,
                status: isExporting ? `Exporting... ${exportedUsers.length} users found` : 'Ready'
            });
        } else {
                sendResponse({ success: false, message: 'Unknown action' });
            }
        } catch (error) {
            console.error('Error handling message:', error);
            sendResponse({ success: false, message: error.message });
        }
        
        // Return true to indicate we will send a response asynchronously
        return true;
    });
    
    // Send ready message to popup
    try {
        chrome.runtime.sendMessage({
            action: 'contentScriptReady',
            success: true,
            message: 'Content script loaded successfully'
        });
    } catch (error) {
        console.log('Ready message failed:', error);
    }
}

function startExport(options) {
    if (isExporting) return;
    
    console.log('Starting Discord user export with options:', options);
    isExporting = true;
    exportedUsers = [];
    
    // Wait for Discord to load - SIMPLE DELAY
    setTimeout(() => {
        loadAllUsers(options);
    }, 1000); // Simple 1 second delay
}

function stopExport() {
    console.log('Stopping export');
    isExporting = false;
}

async function loadAllUsers(options) {
    try {
        // First, try to get the total member count
        await estimateTotalUsers();
        
        // Skip slow approaches and go straight to simple scrolling
        console.log('Starting fast member collection...');
        await scrollAndCollectUsers(options);
        
        // Export the collected users
        if (exportedUsers.length > 0) {
            await exportToJSON(options);
        } else {
            console.log('No users found to export');
            try {
        chrome.runtime.sendMessage({
                    action: 'exportComplete',
                    success: false,
                    message: 'No users found'
                });
            } catch (error) {
                console.log('Export completion message failed:', error);
            }
        }
    } catch (error) {
        console.error('Error during export:', error);
        try {
            chrome.runtime.sendMessage({
                action: 'exportComplete',
                success: false,
                message: error.message
            });
        } catch (messageError) {
            console.log('Error message sending failed:', messageError);
        }
        isExporting = false;
        return;
    }
    
    isExporting = false;
}

async function estimateTotalUsers() {
    // Try to find member count in the UI
    const memberCountElements = document.querySelectorAll('[class*="memberCount"], [class*="member-count"]');
    for (const element of memberCountElements) {
        const text = element.textContent;
        const match = text.match(/(\d+)/);
        if (match) {
            totalUsers = parseInt(match[1]);
            console.log('Estimated total users:', totalUsers);
            return;
        }
    }
    
    // Fallback: estimate based on visible members
    const visibleMembers = document.querySelectorAll(SELECTORS.memberItem);
    totalUsers = Math.max(visibleMembers.length * 10, 1000); // Rough estimate
        console.log('Estimated total users (fallback):', totalUsers);
}

async function scrollAndCollectUsers(options) {
    const scrollContainer = findMemberListContainer();
    if (!scrollContainer) {
        throw new Error('Could not find member list container. Please make sure you are on a Discord server page and the member list is visible.');
    }
    
    console.log('Starting REAL scrolling member collection...');
    
    // Start with initial collection
    const initialUsers = collectVisibleUsers(options);
    for (const user of initialUsers) {
        if (!exportedUsers.find(u => u.id === user.id)) {
            exportedUsers.push(user);
        }
    }
    
    console.log(`Initial collection: ${exportedUsers.length} users found`);
    
    // Dynamic speed scrolling - adjust based on Discord's response
    let previousUserCount = exportedUsers.length;
    let noProgressCount = 0;
    const maxNoProgressAttempts = 3;
    let currentDelay = 100; // Start fast, slow down if needed
    
    for (let attempt = 0; attempt < 500 && isExporting; attempt++) {
        // Real scrolling - scroll down like a human would
        await performRealScrolling(scrollContainer, attempt);
        
        // Dynamic delay - slow down if Discord can't keep up
        await sleep(currentDelay);
        
        // Collect any new users
        const newUsers = collectVisibleUsers(options);
        const currentUserCount = exportedUsers.length;
        
        for (const user of newUsers) {
            if (!exportedUsers.find(u => u.id === user.id)) {
                exportedUsers.push(user);
            }
        }
        
        const newUserCount = exportedUsers.length - currentUserCount;
        
        if (newUserCount > 0) {
            console.log(`Attempt ${attempt + 1}: Found ${newUserCount} new users (Total: ${exportedUsers.length}) - Speed: ${currentDelay}ms`);
            noProgressCount = 0;
            previousUserCount = exportedUsers.length;
            
            // Speed up if we're finding users consistently
            if (currentDelay > 50) {
                currentDelay = Math.max(50, currentDelay - 10);
                console.log(`🚀 Speeding up! New delay: ${currentDelay}ms`);
            }
        } else {
            noProgressCount++;
            console.log(`Attempt ${attempt + 1}: No new users found (${noProgressCount}/${maxNoProgressAttempts}) - Speed: ${currentDelay}ms`);
            
            // Slow down if Discord can't keep up
            if (noProgressCount >= 2) {
                currentDelay = Math.min(500, currentDelay + 50);
                console.log(`🐌 Slowing down for Discord! New delay: ${currentDelay}ms`);
            }
        }
        
        // If we haven't made progress for too long, try a different approach
        if (noProgressCount >= maxNoProgressAttempts) {
            console.log('No progress for too long, trying alternative real scrolling...');
            await tryAlternativeRealScrolling(scrollContainer);
            noProgressCount = 0;
        }
        
        // Update progress with error handling
        try {
            chrome.runtime.sendMessage({
                action: 'updateProgress',
                totalUsers: totalUsers || exportedUsers.length,
                exportedUsers: exportedUsers.length,
                progress: Math.min((exportedUsers.length / (totalUsers || 1000)) * 100, 100)
            });
        } catch (error) {
            console.log('Progress update failed:', error);
        }
        
        // If we've been running for a while and haven't found new users, break
        if (attempt > 200 && noProgressCount > 10) {
            console.log('Stopping collection - no progress for too long');
            break;
        }
    }
    
    console.log(`Collection complete: ${exportedUsers.length} users found`);
}

// Cache the scrollable element once we find it
let cachedScrollElement = null;

async function findCorrectScrollableElement() {
    console.log('🔍 Looking for Discord member list scrollable element...');
    
    // Try the specific Discord member list element first
    const memberListElement = document.querySelector('[data-list-id^="members-"]');
    if (memberListElement) {
        console.log(`✅ Found Discord member list element: ${memberListElement.className}`);
        console.log(`  scrollHeight: ${memberListElement.scrollHeight}, clientHeight: ${memberListElement.clientHeight}`);
        
        // Test if it can scroll
        const initialScrollTop = memberListElement.scrollTop;
        memberListElement.scrollTop = initialScrollTop + 100;
        
        if (memberListElement.scrollTop !== initialScrollTop) {
            console.log(`✅ Element CAN scroll! New scrollTop: ${memberListElement.scrollTop}`);
            // Reset scroll position
            memberListElement.scrollTop = initialScrollTop;
            return memberListElement;
        } else {
            console.log(`❌ Element cannot scroll (scrollTop unchanged)`);
        }
    }
    
    // Fallback: try other potential elements
    const candidates = [
        document.querySelector('[class*="scrollerBase"]'),
        document.querySelector('[class*="members"]'),
        document.querySelector('[class*="memberList"]'),
        document.querySelector('aside'),
        document.querySelector('[role="listbox"]'),
        document.querySelector('[role="list"]')
    ].filter(el => el);
    
    console.log(`Found ${candidates.length} fallback elements`);
    
    for (let i = 0; i < candidates.length; i++) {
        const element = candidates[i];
        const initialScrollTop = element.scrollTop;
        const initialScrollHeight = element.scrollHeight;
        const initialClientHeight = element.clientHeight;
        
        console.log(`Testing fallback element ${i + 1}: ${element.tagName} ${element.className}`);
        
        if (initialScrollHeight > initialClientHeight) {
            element.scrollTop = initialScrollTop + 100;
            
            if (element.scrollTop !== initialScrollTop) {
                console.log(`✅ Fallback element ${i + 1} CAN scroll!`);
                element.scrollTop = initialScrollTop;
                return element;
            }
        }
    }
    
    console.log('❌ No scrollable element found');
    return null;
}

async function performRealScrolling(scrollContainer, attempt) {
    // Find the correct scrollable element if we haven't cached it yet
    if (!cachedScrollElement) {
        cachedScrollElement = await findCorrectScrollableElement();
        
        if (!cachedScrollElement) {
            console.log('❌ No scrollable element found, trying fallback scrolling');
            // Fallback: try scrolling the window
            window.scrollBy(0, 300);
            return;
        }
        
        console.log(`✅ Using cached scrollable element: ${cachedScrollElement.tagName} ${cachedScrollElement.className}`);
    }
    
    const method = attempt % 4; // 4 simple methods
    
    console.log(`📜 Scrolling method ${method + 1} on ${cachedScrollElement.tagName}`);
    
    // Add visual indicator
    cachedScrollElement.style.border = '3px solid #ff0000';
    setTimeout(() => cachedScrollElement.style.border = '', 500);
    
    switch (method) {
        case 0:
            // Method 1: Scroll down by 200px
            cachedScrollElement.scrollTop = cachedScrollElement.scrollTop + 200;
            break;
            
        case 1:
            // Method 2: Scroll down by 300px
            cachedScrollElement.scrollTop = cachedScrollElement.scrollTop + 300;
            break;
            
        case 2:
            // Method 3: Scroll down by 150px
            cachedScrollElement.scrollTop = cachedScrollElement.scrollTop + 150;
            break;
            
        case 3:
            // Method 4: Scroll down by 250px
            cachedScrollElement.scrollTop = cachedScrollElement.scrollTop + 250;
            break;
    }
    
    console.log(`📍 Scroll position: ${cachedScrollElement.scrollTop}/${cachedScrollElement.scrollHeight}`);
}

async function smoothScrollTo(scrollContainer, targetPosition) {
    // Create smooth, visible scrolling animation
    const startPosition = scrollContainer.scrollTop;
    const distance = targetPosition - startPosition;
    const duration = 1200; // Increased to 1.2 seconds for more visible scrolling
    const startTime = performance.now();
    
    console.log(`🔄 Smooth scrolling from ${startPosition} to ${targetPosition} (distance: ${distance}px)`);
    
    // Add visual indicator
    scrollContainer.style.border = '2px solid #00ff00';
    
    return new Promise((resolve) => {
        function animateScroll(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Use easeOutCubic for smooth deceleration
            const easeProgress = 1 - Math.pow(1 - progress, 3);
            const currentPosition = startPosition + (distance * easeProgress);
            
            scrollContainer.scrollTop = currentPosition;
            
            if (progress < 1) {
                requestAnimationFrame(animateScroll);
            } else {
                console.log(`✅ Scroll completed at position ${scrollContainer.scrollTop}`);
                // Remove visual indicator
                scrollContainer.style.border = '';
                resolve();
            }
        }
        
        requestAnimationFrame(animateScroll);
    });
}

async function clickAndDragScrollbar(scrollContainer) {
    console.log('🖱️ Click and drag scrollbar...');
    
    const rect = scrollContainer.getBoundingClientRect();
    
    // Click on scrollbar thumb
    const thumbX = rect.right - 5;
    const thumbY = rect.top + rect.height / 2;
    
    // Mouse down on scrollbar thumb
    const mousedownEvent = new MouseEvent('mousedown', {
        bubbles: true,
        cancelable: true,
        clientX: thumbX,
        clientY: thumbY
    });
    scrollContainer.dispatchEvent(mousedownEvent);
    await sleep(100);
    
    // Drag down
    for (let i = 0; i < 5; i++) {
        const mousemoveEvent = new MouseEvent('mousemove', {
            bubbles: true,
            cancelable: true,
            clientX: thumbX,
            clientY: thumbY + (i * 50)
        });
        scrollContainer.dispatchEvent(mousemoveEvent);
        await sleep(50);
    }
    
    // Mouse up
    const mouseupEvent = new MouseEvent('mouseup', {
        bubbles: true,
        cancelable: true,
        clientX: thumbX,
        clientY: thumbY + 250
    });
    scrollContainer.dispatchEvent(mouseupEvent);
}

async function interactWithScrollbar(scrollContainer) {
    console.log('🖱️ Interacting with scrollbar...');
    
    const rect = scrollContainer.getBoundingClientRect();
    
    // Try clicking on different parts of the scrollbar
    const scrollbarPositions = [
        { x: rect.right - 5, y: rect.top + 20 },   // Top of scrollbar
        { x: rect.right - 5, y: rect.bottom - 20 }, // Bottom of scrollbar
        { x: rect.right - 5, y: rect.top + rect.height / 2 } // Middle of scrollbar
    ];
    
    for (const pos of scrollbarPositions) {
        const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            clientX: pos.x,
            clientY: pos.y
        });
        scrollContainer.dispatchEvent(clickEvent);
        await sleep(100);
    }
    
    // Try dragging the scrollbar thumb
    const thumbRect = scrollContainer.getBoundingClientRect();
    const mousedownEvent = new MouseEvent('mousedown', {
        bubbles: true,
        cancelable: true,
        clientX: thumbRect.right - 5,
        clientY: thumbRect.top + 50
    });
    scrollContainer.dispatchEvent(mousedownEvent);
    
    await sleep(100);
    
    const mousemoveEvent = new MouseEvent('mousemove', {
                bubbles: true,
        cancelable: true,
        clientX: thumbRect.right - 5,
        clientY: thumbRect.bottom - 50
            });
    scrollContainer.dispatchEvent(mousemoveEvent);
    
    await sleep(100);
        
    const mouseupEvent = new MouseEvent('mouseup', {
                bubbles: true,
                cancelable: true
            });
    scrollContainer.dispatchEvent(mouseupEvent);
}

async function tryAlternativeRealScrolling(scrollContainer) {
    console.log('📜 ALTERNATIVE ACTUAL SCROLLING...');
    
    // Just scroll to different positions - no fancy stuff
    const positions = [0, 500, 1000, 1500, 2000, 2500, 3000, 4000, 5000];
    
    for (const pos of positions) {
        console.log(`📜 Scrolling to position ${pos}`);
        scrollContainer.scrollTop = pos;
        await sleep(200);
        console.log(`📍 Now at position: ${scrollContainer.scrollTop}`);
    }
    
    // Scroll to bottom
    console.log('📜 Scrolling to bottom');
    scrollContainer.scrollTop = scrollContainer.scrollHeight;
    await sleep(300);
    
    // Scroll back to top
    console.log('📜 Scrolling back to top');
    scrollContainer.scrollTop = 0;
    await sleep(300);
}

function findMemberListContainer() {
    // Try primary selectors first
    let container = document.querySelector(SELECTORS.scrollContainer);
    
    if (!container) {
        // Try alternative selectors
        const alternatives = ALTERNATIVE_SELECTORS.scrollContainer.split(', ');
        for (const selector of alternatives) {
            container = document.querySelector(selector.trim());
            if (container) {
                console.log('Found member list container:', container);
                break;
            }
        }
    }
    
    if (container) {
    console.log('Found member list container:', container);
    } else {
        console.log('Could not find member list container');
    }
    
    return container;
}

function collectVisibleUsers(options) {
    const users = [];
    const processedIds = new Set();
    
    // Try multiple selectors for member items
    let memberItems = document.querySelectorAll(SELECTORS.memberItem);
    
    if (memberItems.length === 0) {
        // Try alternative selectors
        const alternatives = ALTERNATIVE_SELECTORS.memberItem.split(', ');
        for (const selector of alternatives) {
            memberItems = document.querySelectorAll(selector.trim());
            if (memberItems.length > 0) {
                console.log(`Found ${memberItems.length} member items with selector: ${selector}`);
                break;
            }
        }
    }
    
    console.log(`Total member items found: ${memberItems.length}`);
    
    memberItems.forEach((item, index) => {
        try {
            const user = extractUserData(item, options);
            if (user && user.id && !processedIds.has(user.id)) {
                processedIds.add(user.id);
                    users.push(user);
                console.log(`Extracted user ${index + 1}: ${user.displayName || user.username} (${user.id}) - Roles: ${user.roles.join(', ')}`);
            }
        } catch (error) {
            console.error(`Error extracting user data from item ${index}:`, error);
        }
    });
    
    console.log(`Successfully extracted ${users.length} users from ${memberItems.length} items`);
    return users;
}

function extractUserData(memberItem, options) {
    const user = {
        id: null,
        username: null,
        discriminator: null,
        displayName: null,
        avatar: null,
        roles: [],
        joinDate: null,
        status: null,
        bot: false
    };
    
    // Extract actual Discord user ID from avatar URL or other sources
    let discordUserId = null;
    
    // Method 1: Try to get user ID from avatar URL
    const avatarImg = memberItem.querySelector('[class*="avatar"] img');
    if (avatarImg && avatarImg.src) {
        const avatarMatch = avatarImg.src.match(/avatars\/(\d+)\//);
        if (avatarMatch) {
            discordUserId = avatarMatch[1];
            console.log(`✅ Found user ID from avatar: ${discordUserId}`);
        }
    }
    
    // Method 2: Try to get from data attributes
    if (!discordUserId) {
        const listItemId = memberItem.getAttribute('data-list-item-id');
        if (listItemId && listItemId.includes('___')) {
            // Extract the user index from the list item ID
            const userIndexMatch = listItemId.match(/___(\d+)$/);
            if (userIndexMatch) {
                discordUserId = userIndexMatch[1];
                console.log(`✅ Found user ID from list item: ${discordUserId}`);
            }
        }
    }
    
    // Method 3: Try to extract from any data attributes
    if (!discordUserId) {
        const allAttributes = Array.from(memberItem.attributes);
        for (const attr of allAttributes) {
            if (attr.value && /^\d{17,19}$/.test(attr.value)) {
                // This looks like a Discord user ID (17-19 digits)
                discordUserId = attr.value;
                console.log(`✅ Found user ID from attribute ${attr.name}: ${discordUserId}`);
                break;
            }
        }
    }
    
    // Method 4: Generate unique ID based on username if no Discord ID found
    if (!discordUserId) {
        const username = user.username || 'unknown';
        discordUserId = username.replace(/\s+/g, '_') + '_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
        console.log(`⚠️ Generated fallback ID: ${discordUserId}`);
    }
    
    user.id = discordUserId;
    
    // Extract username and display name from Discord's new structure
    // First, try to find the actual username element (the one highlighted in red)
    let actualUsername = null;
    let displayName = null;
    
    // Method 1: Look for the specific username element that contains the actual username
    const usernameElements = memberItem.querySelectorAll('[class*="username"]');
    for (const element of usernameElements) {
        const text = element.textContent.trim();
        
        // Check if this element contains what looks like an actual username
        // (shorter, no special characters, not the display name)
        if (text && text.length < 50 && !text.includes('|') && !text.includes('ROLI')) {
            // This might be the actual username
            actualUsername = text;
            break;
        }
    }
    
    // Method 2: Look for the display name (longer text with special characters)
    const displayNameElements = memberItem.querySelectorAll('[class*="username"]');
    for (const element of displayNameElements) {
        const text = element.textContent.trim();
        
        // Check if this looks like a display name (longer, with special characters)
        if (text && text.length > 10 && (text.includes('|') || text.includes('ROLI'))) {
            displayName = text;
            break;
        }
    }
    
    // Method 3: Fallback - get all text and try to separate username from display name
    if (!actualUsername || !displayName) {
        const allText = memberItem.textContent;
        const lines = allText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
        
        for (const line of lines) {
            // Look for shorter text that might be username
            if (line.length < 20 && !line.includes('|') && !line.includes('ROLI') && !line.includes('•')) {
                if (!actualUsername) actualUsername = line;
            }
            // Look for longer text that might be display name
            if (line.length > 10 && (line.includes('|') || line.includes('ROLI'))) {
                if (!displayName) displayName = line;
            }
        }
    }
    
    // Set the values
    user.displayName = displayName || actualUsername || 'Unknown';
    user.username = actualUsername || displayName || 'Unknown';
    
    // Try to extract discriminator
    const discriminatorMatch = user.displayName.match(/^(.+)#(\d{4})$/);
    if (discriminatorMatch) {
        user.username = discriminatorMatch[1];
        user.discriminator = discriminatorMatch[2];
    }
    
    console.log(`🔍 Extracted - Display: "${user.displayName}" | Username: "${user.username}" | Same: ${user.displayName === user.username}`);
    
    // Extract avatar if needed
    if (options.includeAvatar) {
        const avatarElement = memberItem.querySelector(SELECTORS.avatar);
        if (avatarElement) {
            user.avatar = avatarElement.src || avatarElement.getAttribute('src');
        }
    }
    
    // Extract roles if needed
    if (options.includeRoles) {
        const roleElements = memberItem.querySelectorAll(SELECTORS.role);
        roleElements.forEach(roleElement => {
            const roleName = roleElement.textContent.trim();
            if (roleName && roleName.length > 0 && roleName.length < 50 && !user.roles.includes(roleName)) {
                user.roles.push(roleName);
            }
        });
    }
    
    // Check if bot
    const textContent = memberItem.textContent?.toLowerCase() || '';
    if (textContent.includes('bot') || textContent.includes('b0t')) {
        user.bot = true;
    }
    
    return user;
}

async function exportToJSON(options) {
    console.log(`Exporting ${exportedUsers.length} users to JSON`);
    
    // Create JSON structure
    const exportData = {
        exportInfo: {
            timestamp: new Date().toISOString(),
            totalUsers: exportedUsers.length,
            serverId: window.location.pathname.split('/')[2] || 'unknown',
            options: options
        },
        users: exportedUsers
    };
    
    // Create and download JSON file
    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `discord_users_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Send completion message with error handling
    try {
    chrome.runtime.sendMessage({
        action: 'exportComplete',
            success: true,
            message: `Successfully exported ${exportedUsers.length} users`,
            downloadUrl: url
    });
    } catch (error) {
        console.log('Export completion message failed:', error);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}