#!/usr/bin/env python3
"""
Simple Discord token validator
"""
import requests
import os
from dotenv import load_dotenv

load_dotenv('config.env')

def test_token():
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        print("❌ No token found in config.env")
        return
    
    print(f"🔍 Testing token: {token[:20]}...")
    print(f"📏 Token length: {len(token)} characters")
    
    # Test token with Discord API
    headers = {
        'Authorization': token,
        'Content-Type': 'application/json'
    }
    
    try:
        response = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
        
        if response.status_code == 200:
            user_data = response.json()
            print(f"✅ Token is VALID!")
            print(f"👤 User: {user_data.get('username', 'Unknown')}#{user_data.get('discriminator', '0000')}")
            print(f"🆔 User ID: {user_data.get('id', 'Unknown')}")
            print(f"📧 Email verified: {user_data.get('verified', False)}")
        elif response.status_code == 401:
            print("❌ Token is INVALID - Unauthorized")
        elif response.status_code == 403:
            print("❌ Token is FORBIDDEN - Account might be restricted")
        else:
            print(f"❌ Unexpected response: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Error testing token: {e}")

if __name__ == "__main__":
    test_token()
