# Installation Instructions

## Quick Setup

1. **Download the Extension**
   - The extension files are in the `discord-user-exporter` folder
   - You can copy this folder to your computer

2. **Install in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Turn on "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the `discord-user-exporter` folder
   - The extension should now appear in your extensions list

3. **Create Simple Icons** (Optional)
   - Create three PNG files: `icon16.png`, `icon48.png`, and `icon128.png`
   - You can use any image editor or online tool
   - Recommended size: 16x16, 48x48, and 128x128 pixels
   - Place them in the extension folder

4. **Test the Extension**
   - Go to any Discord server
   - Click the extension icon in your browser toolbar
   - Try exporting a few users to test functionality

## Why This Extension is Better

### Compared to dSaver:
- **No 10-12k limit**: Can handle servers with 250k+ members
- **Memory efficient**: Uses batch processing instead of loading all users at once
- **Open source**: You can see and modify the code
- **Better error handling**: More robust and reliable
- **Customizable**: Choose what data to export
- **Real-time progress**: See exactly what's happening

### Technical Improvements:
- **Streaming approach**: Processes users as they're loaded, not all at once
- **Smart scrolling**: Automatically detects when to stop scrolling
- **Memory management**: Prevents browser crashes on large servers
- **Rate limit handling**: Better handling of Discord's API limits

## Usage Tips

1. **For Large Servers (100k+ users)**:
   - Be patient, it may take 10-30 minutes
   - Don't close the Discord tab during export
   - Close other tabs to free up memory

2. **For Best Results**:
   - Use Discord in a web browser (not desktop app)
   - Make sure you have permission to view the member list
   - Export during off-peak hours for better performance

3. **If Export Stops Early**:
   - Refresh the Discord page and try again
   - Check if you have proper permissions
   - Try reducing the scroll delay in the code if needed

## Customization

You can modify the extension by editing the files:

- `content.js`: Main logic for extracting users
- `popup.js`: User interface and controls
- `manifest.json`: Extension configuration

Key settings you can adjust:
- `batchSize`: Number of users to process at once (default: 100)
- `scrollDelay`: Delay between scrolls in milliseconds (default: 1000)
- `maxScrollAttempts`: Maximum scroll attempts before stopping (default: 10)


