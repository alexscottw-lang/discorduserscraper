# Discord User Exporter Pro

A Chrome extension that exports Discord server members to CSV format with no limits.

## Features

- **No User Limits**: Can handle servers with 250k+ members
- **Batch Processing**: Processes users in batches to avoid memory issues
- **Customizable Export**: Choose which data to include (roles, join date, avatar, etc.)
- **Real-time Progress**: See export progress and statistics
- **CSV Export**: Clean, formatted CSV output
- **Memory Efficient**: Uses streaming approach to handle large datasets

## Installation

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The extension will be installed and ready to use

## Usage

1. Navigate to any Discord server channel
2. Click the extension icon in your browser toolbar
3. Configure your export options:
   - Include Roles
   - Include Join Date
   - Include Avatar URL
   - Include Activity Status
4. Click "Export All Users"
5. Wait for the export to complete (progress will be shown)
6. Click "Download CSV" when finished

## How It Works

This extension works by:

1. **Scrolling Detection**: Automatically scrolls through the Discord member list
2. **Data Extraction**: Extracts user data from the DOM as it becomes visible
3. **Batch Processing**: Processes users in small batches to avoid memory issues
4. **Smart Scrolling**: Detects when no new users are being loaded and stops
5. **CSV Generation**: Creates a clean CSV file with all collected data

## Technical Improvements Over dSaver

- **No Hard Limits**: No artificial limits on user count
- **Memory Management**: Uses streaming approach instead of loading all users at once
- **Better Error Handling**: More robust error handling and recovery
- **Progress Tracking**: Real-time progress updates
- **Customizable**: Choose what data to export
- **Open Source**: Fully readable and modifiable code

## Troubleshooting

### Export Stops Early
- Make sure you're on a Discord server page (not DM or group chat)
- Try refreshing the page and starting again
- Check if Discord has rate-limited your account

### Missing Users
- The extension scrolls through the member list automatically
- Some users might be hidden due to Discord's privacy settings
- Bots and offline users might not appear in the list

### Performance Issues
- Close other tabs to free up memory
- The extension processes users in batches to avoid memory issues
- Large servers (100k+ users) may take several minutes to export

## Limitations

- Requires access to Discord's web interface
- Can only export users visible in the member list
- Some Discord features (like private servers) may not be accessible
- Export speed depends on Discord's loading speed

## Privacy

This extension:
- Only accesses Discord.com
- Does not send data to external servers
- All processing happens locally in your browser
- Does not store or transmit your Discord data

## License

MIT License - Feel free to modify and distribute.


