# Discord Selfbot Setup Guide

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Edit `config.env` file with your configuration:
```
DISCORD_TOKEN=your_actual_discord_token_here
ROVER_BOT_ID=1087508662883463168
TARGET_SERVER_ID=1429900376861315277
MONITORED_CHANNELS=1234567890123456789,9876543210987654321
MESSAGE_THRESHOLD=200
LOG_FILE=user_logs.txt
```

## Configuration

All configuration is handled through the `config.env` file:

- **DISCORD_TOKEN**: Your Discord user token
- **ROVER_BOT_ID**: Rover bot's Discord ID (default: 1087508662883463168)
- **TARGET_SERVER_ID**: Your server ID where Rover bot commands will be sent
- **MONITORED_CHANNELS**: Comma-separated list of channel IDs to monitor
- **MESSAGE_THRESHOLD**: Minimum message count threshold (default: 200)
- **LOG_FILE**: Name of the log file (default: user_logs.txt)

No additional configuration files needed - everything is loaded directly from `config.env`!

## Usage

Run the selfbot:
```bash
python discord_selfbot.py
```

## Features

- Monitors specified Discord channels for new messages (from startup only)
- Tracks message count per user per server (fresh count from when bot starts)
- Logs users who have sent fewer than 200 messages
- Attempts to get Roblox account information via Rover bot using `/whois discord {user_id}`
- Comprehensive logging to both file and console

## Important Notes

⚠️ **WARNING**: Using selfbots violates Discord's Terms of Service. Use at your own risk.

- The bot will count existing messages when it starts up
- Users with fewer than 200 messages will be logged
- Rover bot integration attempts to get Roblox account info
- All activity is logged to `user_logs.txt`

## Troubleshooting

- Make sure your Discord token is valid
- Ensure the bot has permission to read message history in monitored channels
- Check that Rover bot is present in the servers you're monitoring
- Verify channel IDs are correct (right-click channel → Copy ID)
