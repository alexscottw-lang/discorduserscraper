// Discord User Exporter Pro - Background Script
chrome.runtime.onInstalled.addListener(() => {
    console.log('Discord User Exporter Pro installed');
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'exportComplete') {
        console.log(`Export completed: ${request.userCount} users`);
        // You could add additional processing here if needed
    } else if (request.action === 'exportError') {
        console.error('Export error:', request.error);
    }
    
    sendResponse({success: true});
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
    // Open popup (this is handled by the popup in manifest v3)
});


