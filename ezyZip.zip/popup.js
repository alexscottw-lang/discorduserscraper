// Discord User Exporter Pro - Popup Script
let isExporting = false;
let exportStartTime = null;
let updateInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    const exportBtn = document.getElementById('exportBtn');
    const stopBtn = document.getElementById('stopBtn');
    const status = document.getElementById('status');
    const progressBar = document.getElementById('progressBar');
    const userCount = document.getElementById('userCount');
    const exportedCount = document.getElementById('exportedCount');
    const timeElapsed = document.getElementById('timeElapsed');

    exportBtn.addEventListener('click', startExport);
    stopBtn.addEventListener('click', stopExport);

    function startExport() {
        if (isExporting) return;
        
        isExporting = true;
        exportStartTime = Date.now();
        
        exportBtn.disabled = true;
        stopBtn.disabled = false;
        
        status.textContent = 'Starting export...';
        status.className = 'status info';
        
        // Get export options
        const options = {
            includeRoles: document.getElementById('includeRoles').checked,
            includeJoinDate: document.getElementById('includeJoinDate').checked,
            includeAvatar: document.getElementById('includeAvatar').checked,
            includeActivity: document.getElementById('includeActivity').checked
        };
        
        // Send message to content script
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'startExport',
                options: options
            }, function(response) {
                if (chrome.runtime.lastError) {
                    status.textContent = 'Error: ' + chrome.runtime.lastError.message;
                    status.className = 'status error';
                    resetUI();
                }
            });
        });
        
        // Start update interval
        updateInterval = setInterval(updateStats, 1000);
    }
    
    function stopExport() {
        isExporting = false;
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'stopExport'
            });
        });
        
        resetUI();
    }
    
    function resetUI() {
        isExporting = false;
        exportBtn.disabled = false;
        stopBtn.disabled = true;
        
        if (updateInterval) {
            clearInterval(updateInterval);
            updateInterval = null;
        }
    }
    
    function updateStats() {
        if (!isExporting || !exportStartTime) return;
        
        const elapsed = Math.floor((Date.now() - exportStartTime) / 1000);
        timeElapsed.textContent = `Time: ${elapsed}s`;
        
        // Request current stats from content script
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'getStats'
            }, function(response) {
                if (response && !chrome.runtime.lastError) {
                    userCount.textContent = `Users: ${response.totalUsers || 0}`;
                    exportedCount.textContent = `Exported: ${response.exportedUsers || 0}`;
                    
                    if (response.totalUsers > 0) {
                        const progress = (response.exportedUsers / response.totalUsers) * 100;
                        progressBar.style.width = `${Math.min(progress, 100)}%`;
                    }
                    
                    if (response.status) {
                        status.textContent = response.status;
                        if (response.isComplete) {
                            status.className = 'status success';
                            resetUI();
                            
                            // Show download link
                            if (response.downloadUrl) {
                                const downloadArea = document.getElementById('downloadArea');
                                downloadArea.innerHTML = `
                                    <a href="${response.downloadUrl}" download="discord_inactive_users.json" 
                                       style="display: inline-block; background-color: #28a745; color: white; 
                                              padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                                        Download JSON
                                    </a>
                                `;
                            }
                        } else if (response.error) {
                            status.textContent = 'Error: ' + response.error;
                            status.className = 'status error';
                            resetUI();
                        } else {
                            status.className = 'status info';
                        }
                    }
                }
            });
        });
    }
    
    // Listen for messages from content script
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.action === 'exportComplete') {
            status.textContent = 'Export completed!';
            status.className = 'status success';
            resetUI();
            
            if (request.downloadUrl) {
                const downloadArea = document.getElementById('downloadArea');
                downloadArea.innerHTML = `
                    <a href="${request.downloadUrl}" download="discord_inactive_users.json" 
                       style="display: inline-block; background-color: #28a745; color: white; 
                              padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                        Download JSON
                    </a>
                `;
            }
        } else if (request.action === 'exportError') {
            status.textContent = 'Error: ' + request.error;
            status.className = 'status error';
            resetUI();
        }
    });
});
