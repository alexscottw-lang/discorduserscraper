import discord
import asyncio
import logging
import os
import aiohttp
import json
import time
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables from config.env file
load_dotenv('config.env')

# Configuration from environment
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')
ROVER_BOT_ID = int(os.getenv('ROVER_BOT_ID', '298796807323123712'))
TARGET_SERVER_ID = int(os.getenv('TARGET_SERVER_ID', '1429900376861315277'))
ROLIMONS_SERVER_ID = int(os.getenv('ROLIMONS_SERVER_ID', '1429900376861315277'))
MONITORED_CHANNELS_STR = os.getenv('MONITORED_CHANNELS', '')
MONITORED_CHANNELS = [int(channel_id.strip()) for channel_id in MONITORED_CHANNELS_STR.split(',') if channel_id.strip()]
MESSAGE_THRESHOLD = int(os.getenv('MESSAGE_THRESHOLD', '200'))
LOG_FILE = os.getenv('LOG_FILE', 'user_logs.txt')
WEBHOOK_URL = os.getenv('WEBHOOK_URL')
PRIVATE_INVENTORY_WEBHOOK_URL = os.getenv('PRIVATE_INVENTORY_WEBHOOK_URL')
VALUE_THRESHOLD = int(os.getenv('VALUE_THRESHOLD', '1000'))
MAX_TRADE_ADS = int(os.getenv('MAX_TRADE_ADS', '1000'))

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

class DiscordSelfbot(discord.Client):
    def __init__(self):
        # discord.py-self doesn't use intents the same way
        super().__init__()
        self.rover_bot_id = int(ROVER_BOT_ID)
        self.processed_users = set()  # Track users we've already sent Rover commands for
        self.webhook_sent_users = set()  # Track users we've already sent webhooks for
        self.processing_queue = asyncio.Queue()  # Queue for users to process
        self.queue_processor_running = False
        self.last_search_time = 0  # Track last Discord search API call
        self.load_processed_users()  # Load previously processed users from log file
        
    def load_processed_users(self):
        """Load previously processed users from the log file to prevent duplicates"""
        try:
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('['):  # Skip timestamp lines
                            if line.startswith('webhook:'):
                                # Handle webhook entries: "webhook:discord_id:roblox_id"
                                try:
                                    parts = line.split(':')
                                    if len(parts) == 3:
                                        discord_id = int(parts[1])
                                        roblox_id = int(parts[2])
                                        user_key = f"{discord_id}_{roblox_id}"
                                        self.webhook_sent_users.add(user_key)
                                except ValueError:
                                    continue
                            else:
                                # Handle regular user ID entries
                                try:
                                    user_id = int(line)
                                    self.processed_users.add(user_id)
                                except ValueError:
                                    continue
                logging.info(f"Loaded {len(self.processed_users)} previously processed users from {LOG_FILE}")
            else:
                logging.info(f"No existing log file found at {LOG_FILE}")
        except Exception as e:
            logging.error(f"Error loading processed users: {e}")
    
    def save_processed_user(self, user_id):
        """Save a processed user ID to the log file"""
        try:
            with open(LOG_FILE, 'a') as f:
                f.write(f"{user_id}\n")
        except Exception as e:
            logging.error(f"Error saving processed user {user_id}: {e}")
    
    def save_webhook_user(self, discord_user_id, roblox_user_id):
        """Save a user who received a webhook to prevent duplicates"""
        try:
            with open(LOG_FILE, 'a') as f:
                f.write(f"webhook:{discord_user_id}:{roblox_user_id}\n")
        except Exception as e:
            logging.error(f"Error saving webhook user {discord_user_id}:{roblox_user_id}: {e}")
    
    async def enforce_search_delay(self):
        """Enforce a 5-second delay between Discord search API calls"""
        current_time = time.time()
        time_since_last_search = current_time - self.last_search_time
        
        if time_since_last_search < 5.0:
            delay_needed = 5.0 - time_since_last_search
            logging.info(f"⏳ Waiting {delay_needed:.1f}s before next Discord search")
            await asyncio.sleep(delay_needed)
        
        self.last_search_time = time.time()
        
    async def on_ready(self):
        logging.info(f'Logged in as {self.user}')
        logging.info(f'Monitoring {len(MONITORED_CHANNELS)} channels')
        logging.info('Starting fresh - only counting messages from now on')
        
        # Start the queue processor if not already running
        if not self.queue_processor_running:
            self.queue_processor_running = True
            asyncio.create_task(self.process_queue())
        
        # Initialize empty message counts for each monitored guild
        for channel_id in MONITORED_CHANNELS:
            try:
                channel = self.get_channel(channel_id)
                if channel and channel.guild:
                    guild_id = channel.guild.id
                    if guild_id not in self.user_message_counts:
                        self.user_message_counts[guild_id] = {}
                        logging.info(f'Initialized monitoring for guild: {channel.guild.name}')
            except Exception as e:
                logging.error(f"Error initializing channel {channel_id}: {e}")
    
    async def on_message(self, message):
        # Only process messages from monitored channels
        if message.channel.id not in MONITORED_CHANNELS:
            return
            
        # Don't process messages from bots (including self)
        if message.author.bot:
            return
            
        guild_id = message.guild.id
        user_id = message.author.id
        
        # Check if user hasn't been processed yet
        if user_id not in self.processed_users:
            # Add user to queue immediately - message count will be checked in queue processor
            self.processed_users.add(user_id)  # Mark user as processed
            self.save_processed_user(user_id)  # Save to log file
            await self.processing_queue.put((message.author, "PENDING", message))
            logging.info(f"📥 Added {message.author.name} to queue - Queue size: {self.processing_queue.qsize()}")
    
    async def get_user_total_message_count(self, user_id, guild_id):
        """Get the total message count for a user in a specific server using Discord's search API"""
        try:
            # Use Discord's actual search API endpoint
            url = f"https://discord.com/api/v9/guilds/{guild_id}/messages/search"
            
            params = {
                "author_id": str(user_id),
                "sort_by": "timestamp",
                "sort_order": "desc",
                "offset": "0"
            }
            
            headers = {
                "Authorization": DISCORD_TOKEN,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        total_results = data.get("total_results", 0)
                        return total_results
                    elif response.status == 429:
                        # Rate limited - return special value to indicate retry needed
                        response_text = await response.text()
                        logging.error(f"Discord search API rate limited: {response.status} - {response_text}")
                        return "RATE_LIMITED"
                    else:
                        response_text = await response.text()
                        logging.error(f"Discord search API error: {response.status} - {response_text}")
                        return 0
                        
        except Exception as e:
            logging.error(f"Error getting message count from Discord search API for user {user_id}: {e}")
            return 0
    
    async def process_queue(self):
        """Process users from the queue one at a time with delays"""
        while self.queue_processor_running:
            try:
                # Wait for a user to process (with timeout to check if we should stop)
                try:
                    user_data = await asyncio.wait_for(self.processing_queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue  # Check if we should stop and try again
                
                user, message_count, message = user_data
                logging.info(f"🔄 Processing {user.name} from queue (Queue size: {self.processing_queue.qsize()})")
                
                # Always check message count with 5-second delay between searches
                await self.enforce_search_delay()
                actual_message_count = await self.get_user_total_message_count(user.id, ROLIMONS_SERVER_ID)
                
                if actual_message_count == "RATE_LIMITED":
                    # Still rate limited, add back to queue
                    logging.info(f"⏳ Still rate limited for {user.name}, adding back to queue")
                    await self.processing_queue.put((user, "RATE_LIMITED", message))
                    await asyncio.sleep(5)
                    continue
                elif actual_message_count < MESSAGE_THRESHOLD:
                    # Process the user
                    await self.log_user_and_get_roblox(user, actual_message_count, message)
                else:
                    logging.info(f"⏭️  Skipped {user.name} ({actual_message_count} msgs >= {MESSAGE_THRESHOLD})")
                
                # Wait 5-7 seconds before processing next user
                delay = 5 + (2 * (self.processing_queue.qsize() > 3))  # 5s normally, 7s if queue is busy
                await asyncio.sleep(delay)
                
            except Exception as e:
                logging.error(f"Error in queue processor: {e}")
                await asyncio.sleep(5)  # Wait before retrying
    
    async def log_user_and_get_roblox(self, user, message_count, message=None):
        """Log user information and attempt to get Roblox account via Rover bot"""
        try:
            # Try to get Roblox account via Rover bot
            await self.get_roblox_account(user)
            
        except Exception as e:
            logging.error(f"Error processing user {user.name}: {e}")
    
    async def get_roblox_account(self, user):
        """Use Rover bot to get Roblox account information"""
        try:
            # Get the target server
            target_server = self.get_guild(TARGET_SERVER_ID)
            if not target_server:
                logging.error(f"Target server {TARGET_SERVER_ID} not found. Available servers: {[guild.id for guild in self.guilds]}")
                return
            
            logging.info(f"Found target server: {target_server.name}")
            
            # Check if Rover bot is in the server
            rover_member = target_server.get_member(self.rover_bot_id)
            if not rover_member:
                logging.error(f"Rover bot not found in server {target_server.name}")
                return
            else:
                logging.info(f"Found Rover bot: {rover_member.name}")
            
            # Find a suitable channel in the target server
            channel = None
            for ch in target_server.text_channels:
                try:
                    # Check if we can send messages and if Rover bot is present
                    if (ch.permissions_for(target_server.me).send_messages and 
                        self.rover_bot_id in [member.id for member in target_server.members]):
                        channel = ch
                        break
                except:
                    continue
            
            if not channel:
                logging.warning(f"No suitable channel found in server {target_server.name} to send Rover command")
                return
            
            try:
                # Send slash command interaction directly via HTTP API
                await self.send_rover_slash_command(channel, user)
                
                # Wait for Rover bot response
                def check_response(m):
                    return (m.author.id == self.rover_bot_id and 
                           m.channel.id == channel.id)
                
                try:
                    response = await self.wait_for('message', check=check_response, timeout=30)
                    # Extract Roblox user ID from Rover's response and get Rolimons data
                    await self.get_rolimons_data(user, response)
                    
                except asyncio.TimeoutError:
                    pass  # Silently handle timeout
                    
            except Exception as e:
                logging.error(f"Error sending Rover command for {user.name} (ID: {user.id}): {e}")
                
        except Exception as e:
            logging.error(f"Error getting Roblox account for {user.name}: {e}")
    
    async def send_rover_slash_command(self, channel, user):
        """Send Rover bot slash command using exact payload structure"""
        try:
            # Create the exact payload structure from your example
            payload = {
                "type": 2,
                "application_id": "298796807323123712",
                "guild_id": str(TARGET_SERVER_ID),
                "channel_id": str(channel.id),
                "data": {
                    "version": "1076786613092364290",
                    "id": "977319353156526141",
                    "name": "whois",
                    "type": 1,
                    "options": [
                        {
                            "type": 1,
                            "name": "discord",
                            "options": [
                                {
                                    "type": 6,
                                    "name": "user",
                                    "value": str(user.id)
                                }
                            ]
                        }
                    ]
                },
                "nonce": str(int(datetime.now().timestamp() * 1000)),
                "session_id": "838f52e4e8680620625b562ac77f422d"
            }
            
            headers = {
                'Authorization': DISCORD_TOKEN,
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    'https://discord.com/api/v9/interactions',
                    headers=headers,
                    json=payload
                ) as response:
                    if response.status in [200, 204]:
                        logging.info(f"Successfully sent Rover slash command for {user.name}")
                    else:
                        response_text = await response.text()
                        logging.error(f"Failed to send Rover command: {response.status} - {response_text}")
                        
        except Exception as e:
            logging.error(f"Error sending Rover slash command: {e}")
    
    async def get_rolimons_data(self, discord_user, rover_response):
        """Extract Roblox user ID from Rover response and get Rolimons data"""
        try:
            # Extract Roblox user ID from Rover's response
            roblox_user_id = self.extract_roblox_id_from_message(rover_response)
            
            if roblox_user_id:
                # Get Rolimons data
                await self.fetch_rolimons_info(discord_user, roblox_user_id)
            else:
                logging.warning(f"Could not extract Roblox ID from Rover response")
                
        except Exception as e:
            logging.error(f"Error getting Rolimons data for {discord_user.name}: {e}")
    
    def extract_roblox_id_from_message(self, message):
        """Extract Roblox user ID from Rover bot Discord message"""
        try:
            import re
            
            # First try to extract from embeds
            if message.embeds:
                for embed in message.embeds:
                    embed_dict = embed.to_dict()
                    
                    # Look in embed fields
                    if 'fields' in embed_dict:
                        for field in embed_dict['fields']:
                            if 'name' in field and 'value' in field:
                                field_name = field['name'].lower()
                                field_value = field['value']
                                
                                if 'roblox user id' in field_name or 'user id' in field_name:
                                    # Extract number from field value
                                    match = re.search(r'(\d+)', field_value)
                                    if match:
                                        return match.group(1)
                    
                    # Look in embed description
                    if 'description' in embed_dict:
                        match = re.search(r'(\d{6,})', embed_dict['description'])
                        if match:
                            return match.group(1)
            
            # Fallback: try to extract from message content
            if message.content:
                patterns = [
                    r'"Roblox user ID":\s*"(\d+)"',  # "Roblox user ID": "296077611"
                    r'Roblox user ID[:\s]*(\d+)',     # "Roblox user ID: 296077611"
                    r'user ID[:\s]*(\d+)',           # "user ID: 296077611"
                    r'ID[:\s]*(\d+)',                # "ID: 296077611"
                    r'(\d{6,})'                      # Any 6+ digit number
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, message.content, re.IGNORECASE)
                    if match:
                        roblox_id = match.group(1)
                        if len(roblox_id) >= 6:
                            return roblox_id
            
            return None
            
        except Exception as e:
            logging.error(f"Error extracting Roblox ID from message: {e}")
            return None
    
    async def fetch_rolimons_info(self, discord_user, roblox_user_id):
        """Fetch inventory value and trade ads from Rolimons API"""
        try:
            url = f"https://api.rolimons.com/players/v1/playerinfo/{roblox_user_id}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Removed verbose API logging for cleaner console
                        
                        # Use API data as primary source, fallback to scraping for trade ads
                        inventory_value = data.get('value', 'Unknown')
                        rap_value = data.get('rap', 'Unknown')
                        username = data.get('name', 'Unknown')
                        
                        # Try to get trade ads via web scraping (fallback if API doesn't have it)
                        trade_ads = await self.get_trade_ads_from_scraping(roblox_user_id)
                        
                        # Determine if inventory is private based on API response
                        is_private_inventory = inventory_value == 'Unknown' or inventory_value is None
                        
                        # Convert string values to numbers for processing
                        if inventory_value == 'Unknown':
                            inventory_value = 0  # Treat unknown as 0 for webhook display
                        elif isinstance(inventory_value, str) and inventory_value.isdigit():
                            inventory_value = int(inventory_value)
                        
                        # Removed verbose Rolimons data logging for cleaner console
                        
                        # Check if user meets criteria and send appropriate webhook (only once per user)
                        user_key = f"{discord_user.id}_{roblox_user_id}"  # Unique key for Discord user + Roblox ID
                        
                        if user_key not in self.webhook_sent_users:
                            self.webhook_sent_users.add(user_key)
                            
                            # Check trade ads filter first
                            if trade_ads > MAX_TRADE_ADS:
                                logging.info(f"User {discord_user.name} has {trade_ads} trade ads (exceeds limit of {MAX_TRADE_ADS}), skipping webhook")
                                return
                            
                            # Save user to webhook log file
                            self.save_webhook_user(discord_user.id, roblox_user_id)
                            
                            # Determine which webhook to send based on inventory status
                            if is_private_inventory:
                                # Private inventory (Unknown value) - send to separate channel
                                if PRIVATE_INVENTORY_WEBHOOK_URL and PRIVATE_INVENTORY_WEBHOOK_URL != 'https://discord.com/api/webhooks/YOUR_PRIVATE_WEBHOOK_URL_HERE':
                                    await self.send_webhook(discord_user, username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=True)
                                else:
                                    logging.warning(f"Private inventory webhook URL not configured for user {discord_user.name}")
                            elif isinstance(inventory_value, (int, float)) and inventory_value >= VALUE_THRESHOLD:
                                # Public inventory with high value - send to main channel
                                await self.send_webhook(discord_user, username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=False)
                            else:
                                logging.info(f"User {discord_user.name} doesn't meet value threshold ({inventory_value} < {VALUE_THRESHOLD})")
                        else:
                            logging.info(f"Webhook already sent for user {discord_user.name} (Roblox ID: {roblox_user_id}), skipping")
                        
                    else:
                        response_text = await response.text()
                        logging.error(f"Failed to fetch Rolimons data for Roblox ID {roblox_user_id}: {response.status} - {response_text}")
                        
        except Exception as e:
            logging.error(f"Error fetching Rolimons data for Roblox ID {roblox_user_id}: {e}")
    
    async def get_trade_ads_from_scraping(self, roblox_user_id):
        """Get trade ads count by scraping Rolimons website (fallback method)"""
        try:
            # Try different URL formats
            urls_to_try = [
                f"https://rolimons.com/player/{roblox_user_id}",
                f"https://rolimons.com/players/{roblox_user_id}",
                f"https://www.rolimons.com/player/{roblox_user_id}",
                f"https://www.rolimons.com/players/{roblox_user_id}"
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls_to_try:
                    try:
                        async with session.get(url) as response:
                            if response.status == 200:
                                html_content = await response.text()
                                
                                # Removed verbose HTML logging for cleaner console
                                
                                # Look for trade ads count in the HTML
                                import re
                                
                                # First, try to extract just the trade ads section
                                trade_ads_section_match = re.search(r'<div[^>]*trade-ads-created-container[^>]*>.*?</div>', html_content, re.DOTALL | re.IGNORECASE)
                                if trade_ads_section_match:
                                    trade_ads_section = trade_ads_section_match.group(0)
                                    
                                    # Look for number in the trade ads section only
                                    section_patterns = [
                                        r'<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'<span[^>]*>([\d,]+)</span>',
                                        r'>([\d,]+)<'
                                    ]
                                    
                                    for i, pattern in enumerate(section_patterns):
                                        matches = re.findall(pattern, trade_ads_section)
                                        if matches:
                                            # Remove commas from the number before converting to int
                                            trade_count = int(matches[0].replace(',', ''))
                                            break
                                
                                # Fallback to full page patterns if section extraction failed
                                if trade_count is None:
                                    # More specific patterns - look for the actual trade ads count section
                                    patterns = [
                                        r'trade-ads-created-container[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'Trade Ads Created[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'<div[^>]*trade-ads-created-container[^>]*>.*?<span[^>]*>([\d,]+)</span>',
                                        r'Trade Ads Created.*?<span[^>]*class="[^"]*stat-data[^"]*"[^>]*>([\d,]+)</span>',
                                        r'stat-header[^>]*>Trade Ads Created[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>'
                                    ]
                                    
                                    for i, pattern in enumerate(patterns):
                                        matches = re.findall(pattern, html_content, re.IGNORECASE)
                                        if matches:
                                            # Remove commas from the number before converting to int
                                            trade_count = int(matches[0].replace(',', ''))
                                            break
                                
                                if trade_count is not None:
                                    return trade_count
                                else:
                                    return 0
                                
                            elif response.status == 404:
                                continue
                            else:
                                continue
                                
                    except Exception as e:
                        continue
                
                return 0
                        
        except Exception as e:
            logging.error(f"Error scraping trade ads for user {roblox_user_id}: {e}")
            return 0
    
    async def send_webhook(self, discord_user, roblox_username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=False):
        """Send webhook notification for high-value users"""
        try:
            # Choose the appropriate webhook URL
            webhook_url = PRIVATE_INVENTORY_WEBHOOK_URL if is_private else WEBHOOK_URL
            
            if not webhook_url or webhook_url == 'your_webhook_url_here' or webhook_url == 'https://discord.com/api/webhooks/YOUR_PRIVATE_WEBHOOK_URL_HERE':
                logging.warning(f"{'Private inventory' if is_private else 'Main'} webhook URL not configured, skipping webhook")
                return
            
            # Create webhook payload with different content for private vs public inventories
            embed_title = "Private Inventory Found" if is_private else "Hit found"
            embed_color = 0xff6b00 if is_private else 0x00ff00  # Orange for private, green for public
            
            webhook_data = {
                "content": "@everyone",
                "embeds": [
                    {
                        "title": embed_title,
                        "color": embed_color,
                        "fields": [
                            {
                                "name": "Discord Username",
                                "value": discord_user.name,
                                "inline": False
                            },
                            {
                                "name": "Discord ID", 
                                "value": str(discord_user.id),
                                "inline": False
                            }
                        ]
                    },
                    {
                        "title": "Rolimons Info",
                        "color": embed_color,
                        "fields": [
                            {
                                "name": "Value",
                                "value": f"{inventory_value:,}" if inventory_value != 0 else "Private Inventory",
                                "inline": False
                            },
                            {
                                "name": "Trade Ads",
                                "value": str(trade_ads),
                                "inline": False
                            },
                            {
                                "name": "Rolimons Profile",
                                "value": f"[Click here to view profile](https://rolimons.com/player/{roblox_user_id})",
                                "inline": False
                            }
                        ],
                        "thumbnail": {
                            "url": f"https://roblox-avatar.eryn.io/{roblox_user_id}"
                        }
                    }
                ]
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(webhook_url, json=webhook_data) as response:
                    if response.status in [200, 204]:
                        webhook_type = "🔒 Private" if is_private else "💰 Main"
                        logging.info(f"✅ {webhook_type} webhook sent for {discord_user.name} (Value: {inventory_value:,})")
                    else:
                        response_text = await response.text()
                        logging.error(f"❌ Failed to send {'private inventory' if is_private else 'main'} webhook: {response.status} - {response_text}")
                        
        except Exception as e:
            logging.error(f"Error sending webhook for {discord_user.name}: {e}")

def main():
    if not DISCORD_TOKEN:
        logging.error("Discord token not found! Please set DISCORD_TOKEN in your config.env file")
        return
        
    if not MONITORED_CHANNELS:
        logging.error("No channels configured for monitoring! Please add channel IDs to MONITORED_CHANNELS in config.env")
        return
    
    # Validate token format
    if len(DISCORD_TOKEN) < 50:
        logging.error(f"Discord token appears to be too short ({len(DISCORD_TOKEN)} chars). Please check your token.")
        return
    
    # Additional token validation
    logging.info(f"Token length: {len(DISCORD_TOKEN)} characters")
    logging.info(f"Token format check: {'PASS' if '.' in DISCORD_TOKEN and len(DISCORD_TOKEN.split('.')) == 3 else 'FAIL'}")
    
    logging.info(f"Starting selfbot with token: {DISCORD_TOKEN[:20]}...")
    logging.info(f"Monitoring {len(MONITORED_CHANNELS)} channels: {MONITORED_CHANNELS}")
    
    client = DiscordSelfbot()
    try:
        client.run(DISCORD_TOKEN)
    except discord.LoginFailure as e:
        logging.error(f"Login failed - Invalid token: {e}")
        logging.error("Please check your Discord token in config.env")
    except Exception as e:
        logging.error(f"Error running selfbot: {e}")

if __name__ == "__main__":
    main()
